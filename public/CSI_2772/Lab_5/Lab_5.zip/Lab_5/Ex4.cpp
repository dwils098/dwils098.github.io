
//Aussi présenter la nouvelle initialisation de C++11

//C++11 brace-init
int a{0};
string s{"hello"};
string s2{s}; //copy construction
double *pd= new double [3] {0.5, 1.2, 12.99};

class C
{
  int x[4];
public:
  C(): x{0,1,2,3} {}int n{}; //zero initialization: n is initialized to 0

  int *p{}; //initialized to nullptr
  double d{}; //initialized to 0.0
  char s[12]{}; //all 12 chars are initialized to '\0'
  string s{}; //same as: string s;
  char *p=new char [5]{}; // all five chars are initialized to '\0'
};

class C
{
  int y[5] {1,2,3,4};
public:
  C();
};

class C
{
  string s("abc");
  double d=0;
  char * p {nullptr};
  int y[5] {1,2,3,4};
public:
  C();
};

class C2
{
  string s;
  double d;
  char * p;
  int y[5];
public:
  C() : s("abc"), d(0.0), p(nullptr), y{1,2,3,4} {}
};

class C
{
  int x=7; //class member initializer
  C(); //x is initialized to 7 when the default ctor is invoked
  C(int y) : x(y) {} //overrides the class member initializer
};
C c; //c.x = 7
C c2(5); //c.x = 5
