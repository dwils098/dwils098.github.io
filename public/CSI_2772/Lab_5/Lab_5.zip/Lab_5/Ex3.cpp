
//entre 0 et 1

r = ((double) rand() / (RAND_MAX))


#include <time.h> // So we can use time() function
#include <iostream> // To output results to console

int main() // Main function required in all C++ programs and first
function to be called
{
srand( time(NULL) ); //Randomize seed initialization
int randNum = rand() % 2; // Generate a random number between 0 and 1

std::cout << randNum; // Output the results to console
return 0; //Generate an "EXIT SUCCESS" return code
}
