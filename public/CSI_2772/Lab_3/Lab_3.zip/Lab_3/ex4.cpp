//Que fait la fonction suivante:
#include <iostream>

int addAndReturn( int& myVal )
{
     int temp = myVal;
     myVal += 1;
     return temp;
}

int main (){
  int x = 9;
  addAndReturn(x);
  std::cout << x << std::endl;
}
