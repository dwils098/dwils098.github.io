#include <iostream>

int main(){
  int num_rows = 5;
  int num_cols = 3;
  int depth = 2;

  int *** arrayI;
  arrayI=new int ** [num_rows];

  for(int i=0; i<num_rows; i++)
  {
          arrayI[i]=new int * [num_cols];
          for(int j=0; j<num_cols; j++)
          {
                  arrayI[i][j]=new int [depth];
                  std::cout << *(arrayI[i][j]) << " ";
          }
          std::cout<<std::endl;
  }

  for(int i=0; i<num_rows; i++)
  {
          for(int j=0; j<num_cols; j++)
          {
                  delete [] arrayI[i][j];
          }
          delete [] arrayI[i];
  }
  delete arrayI;

  return 0;


}



















#include <iostream>

int main(){
  int num_rows = 5;
  int num_cols = 3;
  int depth = 2;

  // declare a pointer to a pointer to a pointer.
  int *** arrayI;
  // define it as a pointer to a pointer to an array of integer of size num_rows.
  arrayI=new int ** [num_rows];

  // for-loop that iterate num_rows times
  for(int i=0; i<num_rows; i++)
  {
          // define the content of the array of integer pointed by the pointer from a pointer
          // to be a pointer to an array of type integer of size num_cols.
          arrayI[i]=new int * [num_cols];

          // nested for-loop that iterate num_cols times
          for(int j=0; j<num_cols; j++)
          {
                  // define the content of the array of array of integer to be an array of
                  // integer of size depth.
                  arrayI[i][j]=new int [depth];
                  std::cout << *(arrayI[i][j]) << " ";
          }
          std::cout<<std::endl;
  }

  for(int i=0; i<num_rows; i++)
  {
          for(int j=0; j<num_cols; j++)
          {
                  // free all the arrays contained in the array of array.
                  delete [] arrayI[i][j];
          }
          // free all the arrays contained in the array.
          delete [] arrayI[i];
  }
  // free the array.
  delete arrayI;

  return 0;


}
