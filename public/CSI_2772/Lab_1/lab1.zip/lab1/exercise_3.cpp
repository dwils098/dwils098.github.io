#include <iostream>

int i = 42;

int main(){
  int i = 100;
  int j = i;

// . . .

  std::cout << "The value of j is ...";
  std::cout << " "<< j << std::endl;
}
